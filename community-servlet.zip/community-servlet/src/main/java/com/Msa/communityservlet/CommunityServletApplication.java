package com.Msa.communityservlet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CommunityServletApplication {

	public static void main(String[] args) {
		SpringApplication.run(CommunityServletApplication.class, args);
	}
}
